<?php declare(strict_types=1);

namespace ModelViewer;

/**
 * @var Module $this
 * @var \Laminas\ServiceManager\ServiceLocatorInterface $serviceLocator
 * @var string $oldVersion
 * @var string $newVersion
 *
 * @var \Omeka\Settings\Settings $settings
 * @var \Doctrine\DBAL\Connection $connection
 * @var array $config
 * @var array $config
 * @var \Omeka\Mvc\Controller\Plugin\Api $api
 */
// $settings = $services->get('Omeka\Settings');
// $connection = $services->get('Omeka\Connection');
// $config = require dirname(__DIR__, 2) . '/config/module.config.php';
// $plugins = $services->get('ControllerPluginManager');
// $api = $plugins->get('api');
