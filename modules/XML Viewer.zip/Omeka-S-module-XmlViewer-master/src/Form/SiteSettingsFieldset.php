<?php declare(strict_types=1);

namespace XmlViewer\Form;

class SiteSettingsFieldset extends SettingsFieldset
{
}
